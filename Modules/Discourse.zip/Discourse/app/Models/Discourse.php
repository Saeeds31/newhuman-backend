<?php

namespace Modules\Discourse\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Modules\Discourse\Database\Factories\DiscourseFactory;

class Discourse extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'title',
        'slug',
        'discourse_with',
        'video',
        'main_image',
        'subjects',
        'guest_id',
        'short_description',
        'description',
        'discourse_category_id'
    ];
    protected $table = "discourses";
    public function category()
    {
        return $this->belongsTo(DiscourseCategory::class);
    }
    public function guest()
    {
        return $this->belongsTo(Guest::class);
    }
}
