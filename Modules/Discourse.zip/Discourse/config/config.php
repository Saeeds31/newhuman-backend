<?php

return [
    'name' => 'Discourse',
];
