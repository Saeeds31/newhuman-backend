<?php

return [
    'name' => 'ArticleCategories',
];
